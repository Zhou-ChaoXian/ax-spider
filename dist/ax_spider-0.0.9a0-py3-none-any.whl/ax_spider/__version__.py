# coding: utf-8

__title__ = 'ax_spider'
__version__ = '0.0.9a0'
__license__ = 'GPLv3'
