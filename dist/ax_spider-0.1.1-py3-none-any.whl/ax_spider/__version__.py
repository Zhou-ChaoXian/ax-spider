# coding: utf-8

__title__ = 'ax_spider'
__version__ = '0.1.1'
__license__ = 'GPLv3'
