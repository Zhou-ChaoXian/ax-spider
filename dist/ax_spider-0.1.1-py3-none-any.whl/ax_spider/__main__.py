# coding: utf-8

from .commands import run

if __name__ == '__main__':
    run()
