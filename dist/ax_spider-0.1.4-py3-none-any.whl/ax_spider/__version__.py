# coding: utf-8

__title__ = 'ax_spider'
__version__ = '0.1.4'
__license__ = 'GPLv3'
