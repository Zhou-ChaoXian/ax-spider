# coding: utf-8

spider_opened = object()
spider_idle = object()
spider_closed = object()
request_received = object()
request_error = object()
response_received = object()
item_received = object()
